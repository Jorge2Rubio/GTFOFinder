---
functions:
  shell:
    - code: torsocks /bin/sh
  sudo:
    - code: sudo torsocks /bin/sh
---
