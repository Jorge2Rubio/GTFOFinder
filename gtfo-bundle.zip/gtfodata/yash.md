---
functions:
  shell:
    - code: yash
  suid:
    - code: ./yash
  sudo:
    - code: sudo yash
---
