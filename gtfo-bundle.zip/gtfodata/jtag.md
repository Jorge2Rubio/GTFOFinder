---
functions:
  shell:
    - code: |
       jtag --interactive
       shell /bin/sh
  sudo:
    - code: |
       sudo jtag --interactive
       shell /bin/sh
---
