---
functions:
  shell:
    - code: fish
  suid:
    - code: ./fish
  sudo:
    - code: sudo fish
---
