---
functions:
  sudo:
    - code: sudo pkexec /bin/sh
---
